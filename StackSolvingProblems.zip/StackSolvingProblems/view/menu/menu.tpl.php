<!DOCTYPE html>
<html>
<head>
    <title>PIM</title>
    <link rel="stylesheet" type="text/css" href="menu.tpl.css">
</head>
<body>
    <div>
    
        <header class=headerMenu>
            <form action="" >
                <input class="usLayout" type="submit" value="Login/Register" />
            </form>
            <form action="" >
                  <input class="usLayout" type="submit" value="Ideea/Forum" />
                </form>
    </div>
    
    </header>
</body>
</html>  