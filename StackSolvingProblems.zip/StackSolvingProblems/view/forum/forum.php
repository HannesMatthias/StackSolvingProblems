<!DOCTYPE html>


<html>

    <head>
        <title>Frage die Community</title>
        <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
        <link href="../menu/menu.css" type="text/css" rel="stylesheet" /> 
    </head>

    <body>
        <?php include_once "../menu/menu.php" ?>

    </body>


</html>