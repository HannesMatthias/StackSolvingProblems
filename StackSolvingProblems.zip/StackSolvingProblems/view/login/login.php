<!DOCTYPE html>
<html>
    <head>
        <title>ProjectManagement</title>

        <link rel="stylesheet" href="login.css" />

        <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>


    <body>

    <div class="top"></div>

        <div id="frame">

            <div id="titleform">Community-Projekte &amp; Forum </div>

            <form class="frameform" method="post"> 
                
                <label>Username</label> <input type="text" name="username"> 
                <br />
                <br /> 
                <br /> 
                <label>Passwort</label>
                <input type="password" name="password"> <br> <br>
                <br /> 
                <input type="submit" name="send" value="Abschicken">
            </form>
            <br />
            <br />
            <br />
            <a href="index.php">Zurück zur Startseite</a>
        </div>


    </body>
</html>